package ${package}.beans;

import javax.enterprise.context.RequestScoped;
 
@RequestScoped
public class DemoBean {
 
    public String greet(String name) {
           return "Hello "+ name;
    }
 
}

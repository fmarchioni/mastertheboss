package ${package};

import ${package}.beans.*;
 
import javax.inject.Inject;
 
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
 
import static org.junit.Assert.*;
 
 
@RunWith(Arquillian.class)
public class AppTest {
 
    @Inject
    private DemoBean demoBean;
 
    @Deployment
    public static JavaArchive createDeployment() {
        return ShrinkWrap.create(JavaArchive.class).addClass(DemoBean.class)
                .addAsManifestResource(EmptyAsset.INSTANCE, "beans.xml");
    }
 
    @Test
    public void should_be_deployed() {
        Assert.assertNotNull(demoBean);
    }
 
    @Test
    public void should_greet() {
    	assertEquals(demoBean.greet("Frank"),"Hello Frank");
    } 
}

<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<h1>JBPM web example</h1>
<body>
<a href="jbpmServlet?action=deploy">Deploy  Process</a><br />
<a href="jbpmServlet?action=start">Start new Process</a><br />
<a href="jbpmServlet?action=list">Process List</a>
</body>
</html>
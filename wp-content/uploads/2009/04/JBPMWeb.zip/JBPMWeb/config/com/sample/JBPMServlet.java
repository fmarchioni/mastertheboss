package com.sample;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sample.dao.JBPMDao;

public class JBPMServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String processName;

	 public void init() throws ServletException {
	       
	        // Get the value of an initialization parameter
	        processName = getServletConfig().getInitParameter("processName");    	        
	 }

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = new PrintWriter(response.getOutputStream());

		JBPMDao dao = new JBPMDao();
		String html = null;
		String action = request.getParameter("action");
		
		if (action.equals("deploy")) {
			html = dao.redeployProcess("processdefinition.xml");
		} else if (action.equals("start")) {
			html = dao.startNewProcessInstance(processName);
		} else if (action.equals("list")) {
			html = dao.readProcessInstances(processName);

		} else if (action.equals("signal")) {
			html = dao.signalProcess(processName, request.getParameter("id"));

		}

		out.println(html);
		out.println("<br />");
		out.println("<a href='index.jsp'>Back</a>");
		out.close();
	}

}

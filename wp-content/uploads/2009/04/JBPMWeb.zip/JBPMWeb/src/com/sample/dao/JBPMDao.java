package com.sample.dao;

import java.util.List;

import org.jbpm.graph.def.ProcessDefinition;
import org.jbpm.graph.exe.ProcessInstance;

import org.jbpm.JbpmConfiguration;
import org.jbpm.JbpmContext;
import org.jbpm.db.GraphSession;

public class JBPMDao {
	private static JbpmConfiguration jbpmConfiguration = JbpmConfiguration
			.getInstance();

	public String redeployProcess(String processName) {
		JbpmContext jbpmContext = jbpmConfiguration.createJbpmContext();
		try {
			ProcessDefinition processDefinition = ProcessDefinition
					.parseXmlResource(processName);
			jbpmContext.deployProcessDefinition(processDefinition);

			return "Process " + processDefinition.getName() + " redeployed.";
		} finally {
			jbpmContext.close();
		}
	}

	public String startNewProcessInstance(String processDefinitionName) {

		JbpmContext jbpmContext = jbpmConfiguration.createJbpmContext();
		try {
			GraphSession graphSession = jbpmContext.getGraphSession();
			ProcessDefinition definition = graphSession
					.findLatestProcessDefinition(processDefinitionName);
			ProcessInstance instance = definition.createProcessInstance();
			long id = instance.getId();
			jbpmContext.save(instance);

			return "Started process instance: " + id;
		} finally {
			jbpmContext.close();
		}
	}

	public String readProcessInstances(String processDefinitionName) {

		JbpmContext jbpmContext = jbpmConfiguration.createJbpmContext();

		try {
			GraphSession graphSession = jbpmContext.getGraphSession();
			ProcessDefinition processDefinition = graphSession
					.findLatestProcessDefinition(processDefinitionName);

			List processInstances = jbpmContext.getGraphSession()
					.findProcessInstances(processDefinition.getId());

			String html = ProcessDecorator.drawList(processInstances);

			return html;
		} finally {
			jbpmContext.close();
		}
	}

	public String signalProcess(String processDefinitionName, String id) {

		JbpmContext jbpmContext = jbpmConfiguration.createJbpmContext();
		try {

			long processId = Long.parseLong(id);

			ProcessInstance instance = jbpmContext
					.loadProcessInstance(processId);
			instance.signal();

			String node = instance.getRootToken().getNode().getName();
			StringBuffer sbHtml = new StringBuffer();
			sbHtml.append("Process ");
			sbHtml.append(processId);
			sbHtml.append(" just moved to Node " + node);
			jbpmContext.save(instance);
			return sbHtml.toString();
		} finally {
			jbpmContext.close();
		}
	}

	static class ProcessDecorator {
		private static final String SIGNAL = "jbpmServlet?action=signal";
		private static final String BR = "<br />";

		static String drawList(List processInstances) {
			StringBuffer sbHtml = new StringBuffer();
			sbHtml.append("Process instances");
			sbHtml.append("<hr>");

			for (int ii = 0; ii < processInstances.size(); ii++) {
				ProcessInstance processInstance = (ProcessInstance) processInstances
						.get(ii);
				// We don't display ended processes
				if (processInstance.hasEnded())
					continue;

				String nodeName = processInstance.getRootToken().getNode()
						.getName();
				String processId = String.valueOf(processInstance.getId());

				sbHtml.append("Id              : " + processId);
				sbHtml.append("  Current Node  : <b>" + nodeName + "</b>");
				sbHtml.append("  Start time    : "
								+ processInstance.getStart());
				sbHtml.append("  "
						+ createLink(SIGNAL, "id", processId, "Signal") + BR);

			}
			sbHtml.append("<HR>");
			return sbHtml.toString();
		}

		private static String createLink(String link, String param,
				String value, String description) {
			return "<a href=" + link + "&" + param + "=" + value + ">"
					+ description + "</a>";
		}
	}
}

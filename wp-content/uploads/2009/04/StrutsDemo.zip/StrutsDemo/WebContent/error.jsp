<%@ taglib uri="/WEB-INF/struts-html" prefix="html" %>

<html:html>
<head>
	<title></title>
</head>
<body>
<h1>Login failed</h1>
 
</body>
</html:html>

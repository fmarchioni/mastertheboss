package com.sample;

public class LoginDAO {

	public static boolean login(String username, String password) {
		// TODO Auto-generated method stub
		return true;
	}

}

package sample.jmx;

import org.jboss.annotation.ejb.Depends;
import org.jboss.annotation.ejb.Service;
import org.jboss.annotation.ejb.Management;

@Service(objectName = "sampleJMX:service=financialAdvisor")
@Management(FinancialAdvisor.class)
public class FinancialAdvisorMBean implements FinancialAdvisor {

private CalculateInterest calculateService;

public String getAdvice() {

if (calculateService.getInterestRate() < 5) {
return "Today you invest with low interest rate";
} else if (calculateService.getInterestRate() == 5) {
return "Today you invest with ordinary interest rate";
} else {
return "Today you invest with high interest rate";
}

}

public CalculateInterest getCalculateInterest() {
return calculateService;
}

@Depends("sampleJMX:service=calculateInterest")
public void setCalculateInterest(CalculateInterest calculateService) {
this.calculateService = calculateService;
}

public void create() throws Exception {

System.out.println("FinancialAdvisorMBean - Creating");
}

public void destroy() {
System.out.println("FinancialAdvisorMBean - Destroying");
}
}

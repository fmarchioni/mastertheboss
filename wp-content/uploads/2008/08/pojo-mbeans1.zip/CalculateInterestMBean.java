package sample.jmx; 

import org.jboss.annotation.ejb.Service; 
import org.jboss.annotation.ejb.Management; 

@Service (objectName="sampleJMX:service=calculateInterest") 
@Management(CalculateInterest.class) 
public class CalculateInterestMBean implements CalculateInterest { 

double interestRate; 

public void setInterestRate (double interestRate) { 
this.interestRate = interestRate; 
} 

public double getInterestRate () { 
return interestRate; 
} 

public double calculate (double saving, int days) { 
double interest = (saving * days * this.interestRate)/36500; 
return interest; 
} 

// Lifecycle methods 
public void create() throws Exception { 
this.interestRate = 5; 
System.out.println("CalculateInterestMBean - Creating"); 
} 

public void destroy() { 
System.out.println("CalculateInterestMBean - Destroying"); 
} 

} 
package sample.jmx;

 
public interface FinancialAdvisor {

public String getAdvice();

public CalculateInterest getCalculateInterest();

public void setCalculateInterest(CalculateInterest calculateService);

public void create();

public void destroy();
}

<%@ page import="javax.management.*,sample.jmx.*,org.jboss.mx.util.*" %>

<%
CalculateInterest cal = null;

try {
MBeanServer server = MBeanServerLocator.locate();

cal = (CalculateInterest) MBeanProxyExt.create(
CalculateInterest.class,
"sampleJMX:service=calculateInterest",
server);
cal.setInterestRate(7.5); 
out.println("Amount of Interests: " +cal.calculate(10000, 180)); 

} catch (Exception e) {
e.printStackTrace ();
}
%>


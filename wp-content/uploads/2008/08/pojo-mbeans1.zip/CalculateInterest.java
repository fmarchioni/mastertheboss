package sample.jmx; 

public interface CalculateInterest { 


public void setInterestRate (double interestRate); 
public double getInterestRate ();

// The management method 
public double calculate (double saving, int days); 

// Life cycle method 
public void create () throws Exception; 
public void destroy () throws Exception; 
} 
package com.sample;

import java.util.HashMap;
import java.util.Iterator;

import org.jbpm.graph.def.ProcessDefinition;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.taskmgmt.exe.TaskInstance;

public class SimpleProcessTest {
 public static void main(String args[])throws Exception {
  new SimpleProcessTest().execute();
 }
 public void execute() throws Exception {

 // Extract a process definition from the processdefinition.xml file.
  ProcessDefinition processDefinition = ProcessDefinition.parseXmlResource("simple/processdefinition.xml");
  HashMap map = new HashMap();

  map.put("goodsOrdered",new Integer(100)); 
  map.put("goodsInStock",new Integer(50));

  // Create an instance of the process definition.
  ProcessInstance instance = new ProcessInstance(processDefinition,map);

  displayStatus(instance);

  instance.signal();

  displayStatus(instance);

  executeTask(instance);

  displayStatus(instance);

  executeTask(instance);
  displayStatus(instance);

 }
 
 private void displayStatus(ProcessInstance instance) {   
  String nodeName = instance.getRootToken().getNode().getName();   
  System.out.println("You are now in node: "+nodeName);   
           
 }   
  /* This is a dummy method which prints out the list of TaskInstances  and completes all the single tasks   
 */  
 private void executeTask(ProcessInstance instance) {   
  
  Collection c = instance.getTaskMgmtInstance().getTaskInstances();   
  Iterator iter = c.iterator();   
  while (iter.hasNext()) {   
  
   TaskInstance taskInstance = (TaskInstance)iter.next();   
   System.out.println("Found Task "+taskInstance.getName());   
      
   taskInstance.end();   
      
   System.out.println("Task completed.");   
  }   
           
    
}   

 }

package com.mastertheboss;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
 
import javax.inject.Inject;
import javax.inject.Named;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
 
import javax.jcr.Session;

import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.TreeNode;

@Named
@RequestScoped
public class TreeView implements Serializable {

	private TreeNode root;
	@Inject
	private Session jcrSession;

	@PostConstruct
	public void init() {
		root = new DefaultTreeNode("Root", null);

		try {
			Node rootNode = jcrSession.getRootNode();
			root = newNodeWithChildren(rootNode, null);

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public TreeNode newNodeWithChildren(Node jcrNode, TreeNode parent)
			throws Exception {
		TreeNode newNode = new DefaultTreeNode(jcrNode.getName(), parent);
		NodeIterator nodeList = jcrNode.getNodes();
		while (nodeList.hasNext()) {
			Node tt = (Node) nodeList.next();
			TreeNode newNode2 = newNodeWithChildren(tt, newNode);

		}

		return newNode;
	}

	public TreeNode getRoot() {
		return root;
	}
}
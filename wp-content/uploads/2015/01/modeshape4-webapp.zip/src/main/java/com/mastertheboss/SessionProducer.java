 

package com.mastertheboss;

import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;
import javax.jcr.Repository;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
 

 
public class SessionProducer {

    

    @Resource(mappedName = "java:/jcr/sample")
    private Repository sampleRepository;
 
    @RequestScoped
    @Produces
    public Session getSession() throws RepositoryException {
        System.out.println("Creating new session...");
        return sampleRepository.login();
    }

     
    public void logoutSession( @Disposes final Session session ) {
    	System.out.println("Closing session...");
        session.logout();
    }
}

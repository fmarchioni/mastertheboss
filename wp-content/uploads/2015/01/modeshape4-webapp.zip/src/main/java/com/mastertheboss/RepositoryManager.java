/*
 * ModeShape (http://www.modeshape.org)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * 	http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.mastertheboss;

import javax.enterprise.inject.Model;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.Session;

@Model
public class RepositoryManager {

	String node;
	String path;

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getNode() {
		return node;
	}

	public void setNode(String node) {
		this.node = node;
	}

	@Inject
	private Session jcrSession;

	public void add() {

		System.out
				.println("Session established successfully to repository at: "
						+ jcrSession.getRepository());

		try {
			Node rootNode = jcrSession.getNode(path);

			rootNode.addNode(node);

			jcrSession.save();
			 FacesContext context = FacesContext.getCurrentInstance();     
	         context.addMessage(null, new FacesMessage("Info", "Added Node " + node ));

		} catch (Exception e) {
			System.out.println("Could not complete request" + e);
		}
	}

}

package com.packtpub.chapter4.bean;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.inject.Inject;
import javax.inject.Named;

import com.packtpub.chapter4.ejb.SingletonBean;
import com.packtpub.chapter4.ejb.SingletonBeanDB;
import com.packtpub.chapter4.qualifier.MyCache;

@Named(value="manager")
@SessionScoped
public class PropertyManager implements Serializable {

	@Inject  
	SingletonBean ejb;	
	/*  If you want to inject @MyCache annotation replace the above with:
	 * 	@Inject @MyCache
	 */
	
	@PostConstruct
	public void init() {
		//System.out.println("Initing the JSF Bean");
		//ejb = new SingletonBeanDB();
	}
	ArrayList  cacheList  = new ArrayList ();

	private String key;
	private String value;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public void save(ActionEvent e) {
		ejb.put(key, value);
	}

	public void clear(ActionEvent e) {
		System.out.println("Called clear");
		ejb.delete();

	}
	public List getCacheList() {
		return ejb.getCache();
	}


	public void get(ActionEvent e) {
		String msg = "Added key = " + key;
		FacesContext.getCurrentInstance().addMessage(null,
				new FacesMessage(FacesMessage.SEVERITY_WARN, msg, null));

	}
}

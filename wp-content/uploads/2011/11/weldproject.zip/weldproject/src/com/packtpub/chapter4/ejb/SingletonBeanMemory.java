package com.packtpub.chapter4.ejb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.enterprise.inject.Alternative;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

 


import com.packtpub.chapter4.entity.Property;
import com.packtpub.chapter4.qualifier.MyCache;

@Singleton

@Alternative 
/*
 * use @MyCache qualifier here to select at injection point this bean implementation
 */
 
public class SingletonBeanMemory implements SingletonBean   {

	private  List<Property> cache;
	@PersistenceContext(unitName = "persistenceUnit")
	private EntityManager em;

 
	
	@PostConstruct
	public void initCache(){
		  System.out.println("Inited Memory Cache");
		cache = new ArrayList<Property>();
	}

	public void delete(){

		this.cache.clear();
	}
	public void put(String key,String value){
		Property p = new Property();
		p.setKey(key);
		p.setValue(value);


		this.cache.add(p);
	}
	public List<Property> getCache() {
		return cache;
	}




}

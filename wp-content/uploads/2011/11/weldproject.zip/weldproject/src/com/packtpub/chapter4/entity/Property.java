package com.packtpub.chapter4.entity;


import javax.persistence.*;

@Entity
public class Property {

	@Id( )
	@Column(name="id")
	private String key;
	
	@Column(name="value")
	private String value;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public Property() {

	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}




}

package com.packtpub.chapter4.ejb;

 
import java.util.List;

import com.packtpub.chapter4.entity.Property;

public interface SingletonBean {
	 
	 public void initCache();

	 public void delete();
	 
	 public void put(String key,String value);
	 
	 public List<Property> getCache();
	 
	 
}

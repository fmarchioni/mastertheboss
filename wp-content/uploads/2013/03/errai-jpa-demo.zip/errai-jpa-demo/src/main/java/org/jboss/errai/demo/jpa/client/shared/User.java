package org.jboss.errai.demo.jpa.client.shared;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import org.jboss.errai.common.client.api.annotations.Portable;

@NamedQueries ({
  @NamedQuery(name="allUsers", query="SELECT a FROM User a ORDER BY a.birthday"),
  @NamedQuery(name="UserByName", query="SELECT a FROM User a WHERE a.name=:name")
})
@Portable @Entity
public class User {

  @GeneratedValue
  @Id
  private Long id;

  private String name;

   
  private Date birthday;

   

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }
 

  public Date getBirthday() {
	return birthday;
}

public void setBirthday(Date birthday) {
	this.birthday = birthday;
}

public void setName(String name) {
    this.name = name;
  }

   

  
   

   
}

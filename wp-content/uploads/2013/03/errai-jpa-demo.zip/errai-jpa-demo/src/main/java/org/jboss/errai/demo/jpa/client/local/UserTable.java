package org.jboss.errai.demo.jpa.client.local;

import java.util.List;

import org.jboss.errai.demo.jpa.client.shared.User;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.i18n.shared.DateTimeFormat;
import com.google.gwt.i18n.shared.DateTimeFormat.PredefinedFormat;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;


public class UserTable extends FlexTable {

  private RowOperationHandler<User> deleteHandler;
  private RowOperationHandler<User> editHandler;

  public UserTable() {
    addStyleName("userTable");

    ColumnFormatter cf = getColumnFormatter();
    cf.setStyleName(0, "userName");
    cf.setStyleName(1, "birthday");
    cf.setStyleName(2, "deleteButton");
  }

  public void addAll(List<User> entries) {
    for (User a : entries) {
      add(a);
    }
  }

  public void add(final User a) {

    Button editButton = new Button("Edit...");
    editButton.addClickHandler(new ClickHandler() {
      @Override
      public void onClick(ClickEvent event) {
        if (editHandler != null) {
          editHandler.handle(a);
        }
      }
    });

    Button deleteButton = new Button("Delete");
    deleteButton.addClickHandler(new ClickHandler() {
      @Override
      public void onClick(ClickEvent event) {
        if (deleteHandler != null) {
          deleteHandler.handle(a);
        }
      }
    });

    int row = getRowCount();
    insertRow(row);
    insertCells(row, 0, 3);
    setText(row, 0, a.getName());
    setText(row, 1, a.getBirthday() == null ? "" :
      DateTimeFormat.getFormat(PredefinedFormat.DATE_SHORT).format(a.getBirthday()));
    setWidget(row, 2, editButton);
    setWidget(row, 3, deleteButton);
  }

  public void setDeleteHandler(RowOperationHandler<User> handler) {
    deleteHandler = handler;
  }

  public void setEditHandler(RowOperationHandler<User> handler) {
    editHandler = handler;
  }
}

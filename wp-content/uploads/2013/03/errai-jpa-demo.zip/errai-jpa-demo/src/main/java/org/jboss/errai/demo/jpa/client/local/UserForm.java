package org.jboss.errai.demo.jpa.client.local;

import javax.persistence.EntityManager;

import org.jboss.errai.demo.jpa.client.shared.User;
 

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.datepicker.client.DatePicker;


public class UserForm extends Composite {

  // Note: for simplicity, and to keep this JPA demo on-topic, we are using
  // plain GWT programmatic layout rather than ErraiUI, UIBinder, or Errai Data
  // Binding. See the grocery list demo for the full-on Errai development experience.

  private final EntityManager em;

  private final User user;

  private final TextBox name = new TextBox();
 
  private final DatePicker birthday = new DatePickerWithYearSelector();

  private final Button saveButton = new Button("Save");

  private RowOperationHandler<User> saveHandler;

  public UserForm(final User user, EntityManager em) {
    this.user = user;
    this.em = em;

    

    saveButton.addClickHandler(new ClickHandler() {
      @Override
      public void onClick(ClickEvent event) {
    	  updateUserFromUI();
        if (saveHandler != null) {
          saveHandler.handle(user);
        }
      }
    });

    updateUIFromUser();

    Grid g = new Grid(5, 2);

    int row = 0;
    g.setText(row, 0, "Name:");
    g.setWidget(row, 1, name);

    

    row++;
    g.setText(row, 0, "Birthday:");
    g.setWidget(row, 1, birthday);

    row++;
    g.setWidget(row, 1, saveButton);

    initWidget(g);
  }

  protected void updateUserFromUI() {
    user.setName(name.getText()); 
    user.setBirthday(birthday.getValue());
  }

  private void updateUIFromUser() {

    // Note: with Errai Data Sync, the code in this method would be unnecessary. See the Grocery List demo for an example.

    name.setText(user.getName());

    

    if (user.getBirthday() != null) {
    	birthday.setValue(user.getBirthday());
    	birthday.setCurrentMonth(user.getBirthday());
    }
  }

  public void setSaveHandler(RowOperationHandler<User> handler) {
    this.saveHandler = handler;
  }

  public void grabFocus() {
    name.setFocus(true);
  }
}

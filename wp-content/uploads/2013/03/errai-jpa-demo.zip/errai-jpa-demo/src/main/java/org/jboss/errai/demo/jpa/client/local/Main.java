package org.jboss.errai.demo.jpa.client.local;

import java.sql.Date;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.jboss.errai.demo.jpa.client.shared.User;

import org.jboss.errai.ioc.client.api.EntryPoint;
import org.jboss.errai.jpa.client.local.ErraiEntityManager;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.RootPanel;

@EntryPoint
public class Main {

  @Inject EntityManager em;

  private UserTable usersWidget = new UserTable();

  private Button resetEverythingButton = new Button("Reset all data to defaults");
  private Button newUserButton = new Button("New User");


  @PostConstruct
  public void init() {

    usersWidget.setDeleteHandler(new RowOperationHandler<User>() {
      @Override
      public void handle(User a) {
        em.remove(a);
        em.flush();
        refreshUI();
      }
    });

    usersWidget.setEditHandler(new RowOperationHandler<User>() {
      @Override
      public void handle(User a) {
        UserForm af = new UserForm(a, em);
        final PopupPanel pp = new PopupPanel(true, true);
        af.setSaveHandler(new RowOperationHandler<User>() {
          @Override
          public void handle(User album) {
            em.flush();
            refreshUI();
            pp.hide();
          }
        });
        pp.setWidget(af);
        pp.setGlassEnabled(true);
        pp.show();
        af.grabFocus();
      }
    });

    resetEverythingButton.addClickHandler(new ClickHandler() {
      @Override
      public void onClick(ClickEvent event) {
        ((ErraiEntityManager) em).removeAll();
        preFillDatabaseIfEmpty();
        refreshUI();
      }
    });

    newUserButton.addClickHandler(new ClickHandler() {
      @Override
      public void onClick(ClickEvent event) {
        UserForm af = new UserForm(new User(), em);
        final PopupPanel pp = new PopupPanel(true, true);
        af.setSaveHandler(new RowOperationHandler<User>() {
          @Override
          public void handle(User album) {
            em.persist(album);
            em.flush();
            refreshUI();
            pp.hide();
          }
        });
        pp.setWidget(af);
        pp.setGlassEnabled(true);
        pp.show();
        af.grabFocus();
      }
    });

    
    preFillDatabaseIfEmpty();
    refreshUI();

    RootPanel.get().add(resetEverythingButton);
    RootPanel.get().add(usersWidget);
    RootPanel.get().add(newUserButton);

  }

  private void refreshUI() {
    TypedQuery<User> albums = em.createNamedQuery("allUsers", User.class);
    usersWidget.removeAllRows();
    usersWidget.addAll(albums.getResultList());
  }

  /**
   * If there are no Album instances in the database, this method creates and
   * persists a selection of music from the 1960's.
   */
  private void preFillDatabaseIfEmpty() {
    TypedQuery<User> users = em.createNamedQuery("allUsers", User.class);
    if (users.getResultList().isEmpty()) {
     
      User user = new User();

      user.setName("John");
      user.setBirthday(new Date(11012400000L));
      em.persist(user);

      user = new User();
      user.setName("Mark");
      user.setBirthday(new Date(-8366400000L));
      em.persist(user);

      user = new User();
      user.setName("George");
      user.setBirthday(new Date(-30481200000L));
      em.persist(user);

   

      // store them
      em.flush();
    }
  }

}

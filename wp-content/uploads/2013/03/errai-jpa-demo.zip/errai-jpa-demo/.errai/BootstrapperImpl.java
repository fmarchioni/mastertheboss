package org.jboss.errai.ioc.client;

import java.lang.annotation.Annotation;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Default;
import javax.inject.Provider;
import javax.persistence.EntityManager;
import org.jboss.errai.databinding.client.DataBinderProvider;
import org.jboss.errai.databinding.client.DataBindingModuleBootstrapper;
import org.jboss.errai.demo.jpa.client.local.Main;
import org.jboss.errai.enterprise.client.cdi.CDIEventTypeLookup;
import org.jboss.errai.enterprise.client.cdi.EventProvider;
import org.jboss.errai.enterprise.client.cdi.InstanceProvider;
import org.jboss.errai.enterprise.client.cdi.api.CDI;
import org.jboss.errai.ioc.client.api.ContextualTypeProvider;
import org.jboss.errai.ioc.client.api.builtin.CallerProvider;
import org.jboss.errai.ioc.client.api.builtin.DisposerProvider;
import org.jboss.errai.ioc.client.api.builtin.IOCBeanManagerProvider;
import org.jboss.errai.ioc.client.api.builtin.InitBallotProvider;
import org.jboss.errai.ioc.client.api.builtin.MessageBusProvider;
import org.jboss.errai.ioc.client.api.builtin.RequestDispatcherProvider;
import org.jboss.errai.ioc.client.api.builtin.RootPanelProvider;
import org.jboss.errai.ioc.client.api.builtin.SenderProvider;
import org.jboss.errai.ioc.client.container.CreationalCallback;
import org.jboss.errai.ioc.client.container.CreationalContext;
import org.jboss.errai.ioc.client.container.IOCBeanManager;
import org.jboss.errai.ioc.client.container.InitializationCallback;
import org.jboss.errai.jpa.client.local.ErraiEntityManagerProvider;

public class BootstrapperImpl implements Bootstrapper {
  {
    new CDI().initLookupTable(CDIEventTypeLookup.get());
    new DataBindingModuleBootstrapper().run();
  }
  private final Any _1998831462Any_1671515016 = new Any() {
    public Class annotationType() {
      return Any.class;
    }
  };
  private final Default _1998831462Default_1510378308 = new Default() {
    public Class annotationType() {
      return Default.class;
    }
  };
  private final Annotation[] arrayOf_19635043Annotation_1615093493 = new Annotation[] { _1998831462Any_1671515016, _1998831462Default_1510378308 };
  private final BootstrapperInjectionContext injContext = new BootstrapperInjectionContext();
  private final CreationalContext context = injContext.getRootContext();
  private final CreationalCallback<RequestDispatcherProvider> inj3773_RequestDispatcherProvider_creational = new CreationalCallback<RequestDispatcherProvider>() {
    public RequestDispatcherProvider getInstance(final CreationalContext context) {
      final RequestDispatcherProvider inj3752_RequestDispatcherProvider = new RequestDispatcherProvider();
      context.addBean(context.getBeanReference(RequestDispatcherProvider.class, arrayOf_19635043Annotation_1615093493), inj3752_RequestDispatcherProvider);
      return inj3752_RequestDispatcherProvider;
    }
  };
  private final RequestDispatcherProvider inj3752_RequestDispatcherProvider = inj3773_RequestDispatcherProvider_creational.getInstance(context);
  private final CreationalCallback<DataBinderProvider> inj3774_DataBinderProvider_creational = new CreationalCallback<DataBinderProvider>() {
    public DataBinderProvider getInstance(final CreationalContext context) {
      final DataBinderProvider inj3760_DataBinderProvider = new DataBinderProvider();
      context.addBean(context.getBeanReference(DataBinderProvider.class, arrayOf_19635043Annotation_1615093493), inj3760_DataBinderProvider);
      return inj3760_DataBinderProvider;
    }
  };
  private final DataBinderProvider inj3760_DataBinderProvider = inj3774_DataBinderProvider_creational.getInstance(context);
  private final CreationalCallback<ErraiEntityManagerProvider> inj3775_ErraiEntityManagerProvider_creational = new CreationalCallback<ErraiEntityManagerProvider>() {
    public ErraiEntityManagerProvider getInstance(final CreationalContext context) {
      final ErraiEntityManagerProvider inj3758_ErraiEntityManagerProvider = new ErraiEntityManagerProvider();
      context.addBean(context.getBeanReference(ErraiEntityManagerProvider.class, arrayOf_19635043Annotation_1615093493), inj3758_ErraiEntityManagerProvider);
      return inj3758_ErraiEntityManagerProvider;
    }
  };
  private final ErraiEntityManagerProvider inj3758_ErraiEntityManagerProvider = inj3775_ErraiEntityManagerProvider_creational.getInstance(context);
  private InitializationCallback<Main> init_inj3776_Main = new InitializationCallback<Main>() {
    public void init(final Main obj) {
      obj.init();
    }
  };
  private final CreationalCallback<Main> inj3777_Main_creational = new CreationalCallback<Main>() {
    public Main getInstance(final CreationalContext context) {
      final Main inj3776_Main = new Main();
      context.addBean(context.getBeanReference(Main.class, arrayOf_19635043Annotation_1615093493), inj3776_Main);
      _964176931__615003075_em(inj3776_Main, inj3758_ErraiEntityManagerProvider.get());
      context.addInitializationCallback(inj3776_Main, init_inj3776_Main);
      return inj3776_Main;
    }
  };
  private final Main inj3776_Main = inj3777_Main_creational.getInstance(context);
  private final CreationalCallback<InstanceProvider> inj3778_InstanceProvider_creational = new CreationalCallback<InstanceProvider>() {
    public InstanceProvider getInstance(final CreationalContext context) {
      final InstanceProvider inj3762_InstanceProvider = new InstanceProvider();
      context.addBean(context.getBeanReference(InstanceProvider.class, arrayOf_19635043Annotation_1615093493), inj3762_InstanceProvider);
      return inj3762_InstanceProvider;
    }
  };
  private final InstanceProvider inj3762_InstanceProvider = inj3778_InstanceProvider_creational.getInstance(context);
  private final CreationalCallback<EventProvider> inj3779_EventProvider_creational = new CreationalCallback<EventProvider>() {
    public EventProvider getInstance(final CreationalContext context) {
      final EventProvider inj3766_EventProvider = new EventProvider();
      context.addBean(context.getBeanReference(EventProvider.class, arrayOf_19635043Annotation_1615093493), inj3766_EventProvider);
      return inj3766_EventProvider;
    }
  };
  private final EventProvider inj3766_EventProvider = inj3779_EventProvider_creational.getInstance(context);
  private final CreationalCallback<IOCBeanManagerProvider> inj3780_IOCBeanManagerProvider_creational = new CreationalCallback<IOCBeanManagerProvider>() {
    public IOCBeanManagerProvider getInstance(final CreationalContext context) {
      final IOCBeanManagerProvider inj3756_IOCBeanManagerProvider = new IOCBeanManagerProvider();
      context.addBean(context.getBeanReference(IOCBeanManagerProvider.class, arrayOf_19635043Annotation_1615093493), inj3756_IOCBeanManagerProvider);
      return inj3756_IOCBeanManagerProvider;
    }
  };
  private final IOCBeanManagerProvider inj3756_IOCBeanManagerProvider = inj3780_IOCBeanManagerProvider_creational.getInstance(context);
  private final CreationalCallback<MessageBusProvider> inj3781_MessageBusProvider_creational = new CreationalCallback<MessageBusProvider>() {
    public MessageBusProvider getInstance(final CreationalContext context) {
      final MessageBusProvider inj3750_MessageBusProvider = new MessageBusProvider();
      context.addBean(context.getBeanReference(MessageBusProvider.class, arrayOf_19635043Annotation_1615093493), inj3750_MessageBusProvider);
      return inj3750_MessageBusProvider;
    }
  };
  private final MessageBusProvider inj3750_MessageBusProvider = inj3781_MessageBusProvider_creational.getInstance(context);
  private final CreationalCallback<SenderProvider> inj3782_SenderProvider_creational = new CreationalCallback<SenderProvider>() {
    public SenderProvider getInstance(final CreationalContext context) {
      final SenderProvider inj3772_SenderProvider = new SenderProvider();
      context.addBean(context.getBeanReference(SenderProvider.class, arrayOf_19635043Annotation_1615093493), inj3772_SenderProvider);
      return inj3772_SenderProvider;
    }
  };
  private final SenderProvider inj3772_SenderProvider = inj3782_SenderProvider_creational.getInstance(context);
  private final CreationalCallback<InitBallotProvider> inj3783_InitBallotProvider_creational = new CreationalCallback<InitBallotProvider>() {
    public InitBallotProvider getInstance(final CreationalContext context) {
      final InitBallotProvider inj3764_InitBallotProvider = new InitBallotProvider();
      context.addBean(context.getBeanReference(InitBallotProvider.class, arrayOf_19635043Annotation_1615093493), inj3764_InitBallotProvider);
      return inj3764_InitBallotProvider;
    }
  };
  private final InitBallotProvider inj3764_InitBallotProvider = inj3783_InitBallotProvider_creational.getInstance(context);
  private final CreationalCallback<CallerProvider> inj3784_CallerProvider_creational = new CreationalCallback<CallerProvider>() {
    public CallerProvider getInstance(final CreationalContext context) {
      final CallerProvider inj3768_CallerProvider = new CallerProvider();
      context.addBean(context.getBeanReference(CallerProvider.class, arrayOf_19635043Annotation_1615093493), inj3768_CallerProvider);
      return inj3768_CallerProvider;
    }
  };
  private final CallerProvider inj3768_CallerProvider = inj3784_CallerProvider_creational.getInstance(context);
  private final CreationalCallback<RootPanelProvider> inj3785_RootPanelProvider_creational = new CreationalCallback<RootPanelProvider>() {
    public RootPanelProvider getInstance(final CreationalContext context) {
      final RootPanelProvider inj3754_RootPanelProvider = new RootPanelProvider();
      context.addBean(context.getBeanReference(RootPanelProvider.class, arrayOf_19635043Annotation_1615093493), inj3754_RootPanelProvider);
      return inj3754_RootPanelProvider;
    }
  };
  private final RootPanelProvider inj3754_RootPanelProvider = inj3785_RootPanelProvider_creational.getInstance(context);
  private final CreationalCallback<DisposerProvider> inj3786_DisposerProvider_creational = new CreationalCallback<DisposerProvider>() {
    public DisposerProvider getInstance(final CreationalContext context) {
      final DisposerProvider inj3770_DisposerProvider = new DisposerProvider();
      context.addBean(context.getBeanReference(DisposerProvider.class, arrayOf_19635043Annotation_1615093493), inj3770_DisposerProvider);
      _$1300398733__$121625827_beanManager(inj3770_DisposerProvider, inj3756_IOCBeanManagerProvider.get());
      return inj3770_DisposerProvider;
    }
  };
  private final DisposerProvider inj3770_DisposerProvider = inj3786_DisposerProvider_creational.getInstance(context);
  private void declareBeans_0() {
    injContext.addBean(RequestDispatcherProvider.class, RequestDispatcherProvider.class, inj3773_RequestDispatcherProvider_creational, inj3752_RequestDispatcherProvider, arrayOf_19635043Annotation_1615093493, null, true);
    injContext.addBean(Provider.class, RequestDispatcherProvider.class, inj3773_RequestDispatcherProvider_creational, inj3752_RequestDispatcherProvider, arrayOf_19635043Annotation_1615093493, null, false);
    injContext.addBean(DataBinderProvider.class, DataBinderProvider.class, inj3774_DataBinderProvider_creational, inj3760_DataBinderProvider, arrayOf_19635043Annotation_1615093493, null, true);
    injContext.addBean(ContextualTypeProvider.class, DataBinderProvider.class, inj3774_DataBinderProvider_creational, inj3760_DataBinderProvider, arrayOf_19635043Annotation_1615093493, null, false);
    injContext.addBean(ErraiEntityManagerProvider.class, ErraiEntityManagerProvider.class, inj3775_ErraiEntityManagerProvider_creational, inj3758_ErraiEntityManagerProvider, arrayOf_19635043Annotation_1615093493, null, true);
    injContext.addBean(Provider.class, ErraiEntityManagerProvider.class, inj3775_ErraiEntityManagerProvider_creational, inj3758_ErraiEntityManagerProvider, arrayOf_19635043Annotation_1615093493, null, false);
    injContext.addBean(Main.class, Main.class, inj3777_Main_creational, inj3776_Main, arrayOf_19635043Annotation_1615093493, null, true);
    injContext.addBean(InstanceProvider.class, InstanceProvider.class, inj3778_InstanceProvider_creational, inj3762_InstanceProvider, arrayOf_19635043Annotation_1615093493, null, true);
    injContext.addBean(ContextualTypeProvider.class, InstanceProvider.class, inj3778_InstanceProvider_creational, inj3762_InstanceProvider, arrayOf_19635043Annotation_1615093493, null, false);
    injContext.addBean(EventProvider.class, EventProvider.class, inj3779_EventProvider_creational, inj3766_EventProvider, arrayOf_19635043Annotation_1615093493, null, true);
    injContext.addBean(ContextualTypeProvider.class, EventProvider.class, inj3779_EventProvider_creational, inj3766_EventProvider, arrayOf_19635043Annotation_1615093493, null, false);
    injContext.addBean(IOCBeanManagerProvider.class, IOCBeanManagerProvider.class, inj3780_IOCBeanManagerProvider_creational, inj3756_IOCBeanManagerProvider, arrayOf_19635043Annotation_1615093493, null, true);
    injContext.addBean(Provider.class, IOCBeanManagerProvider.class, inj3780_IOCBeanManagerProvider_creational, inj3756_IOCBeanManagerProvider, arrayOf_19635043Annotation_1615093493, null, false);
    injContext.addBean(MessageBusProvider.class, MessageBusProvider.class, inj3781_MessageBusProvider_creational, inj3750_MessageBusProvider, arrayOf_19635043Annotation_1615093493, null, true);
    injContext.addBean(Provider.class, MessageBusProvider.class, inj3781_MessageBusProvider_creational, inj3750_MessageBusProvider, arrayOf_19635043Annotation_1615093493, null, false);
    injContext.addBean(SenderProvider.class, SenderProvider.class, inj3782_SenderProvider_creational, inj3772_SenderProvider, arrayOf_19635043Annotation_1615093493, null, true);
    injContext.addBean(ContextualTypeProvider.class, SenderProvider.class, inj3782_SenderProvider_creational, inj3772_SenderProvider, arrayOf_19635043Annotation_1615093493, null, false);
    injContext.addBean(InitBallotProvider.class, InitBallotProvider.class, inj3783_InitBallotProvider_creational, inj3764_InitBallotProvider, arrayOf_19635043Annotation_1615093493, null, true);
    injContext.addBean(ContextualTypeProvider.class, InitBallotProvider.class, inj3783_InitBallotProvider_creational, inj3764_InitBallotProvider, arrayOf_19635043Annotation_1615093493, null, false);
    injContext.addBean(CallerProvider.class, CallerProvider.class, inj3784_CallerProvider_creational, inj3768_CallerProvider, arrayOf_19635043Annotation_1615093493, null, true);
    injContext.addBean(ContextualTypeProvider.class, CallerProvider.class, inj3784_CallerProvider_creational, inj3768_CallerProvider, arrayOf_19635043Annotation_1615093493, null, false);
    injContext.addBean(RootPanelProvider.class, RootPanelProvider.class, inj3785_RootPanelProvider_creational, inj3754_RootPanelProvider, arrayOf_19635043Annotation_1615093493, null, true);
    injContext.addBean(Provider.class, RootPanelProvider.class, inj3785_RootPanelProvider_creational, inj3754_RootPanelProvider, arrayOf_19635043Annotation_1615093493, null, false);
    injContext.addBean(DisposerProvider.class, DisposerProvider.class, inj3786_DisposerProvider_creational, inj3770_DisposerProvider, arrayOf_19635043Annotation_1615093493, null, true);
    injContext.addBean(ContextualTypeProvider.class, DisposerProvider.class, inj3786_DisposerProvider_creational, inj3770_DisposerProvider, arrayOf_19635043Annotation_1615093493, null, false);
  }

  private native static void _$1300398733__$121625827_beanManager(DisposerProvider instance, IOCBeanManager value) /*-{
    instance.@org.jboss.errai.ioc.client.api.builtin.DisposerProvider::beanManager = value;
  }-*/;

  private native static void _964176931__615003075_em(Main instance, EntityManager value) /*-{
    instance.@org.jboss.errai.demo.jpa.client.local.Main::em = value;
  }-*/;

  // The main IOC bootstrap method.
  public BootstrapperInjectionContext bootstrapContainer() {
    declareBeans_0();
    return injContext;
  }
}
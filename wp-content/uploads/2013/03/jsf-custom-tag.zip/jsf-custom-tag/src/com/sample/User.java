package com.sample;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class User {
	String name;
	String surname;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public void action() {
		System.out.println("Action called!");
	}
}

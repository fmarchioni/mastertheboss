package com.sample;

import java.util.ArrayList;
import java.util.List;

 

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

 

import com.sample.Property;

@ManagedBean(name="manager")
@SessionScoped
public class PropertyManager {

    
    ArrayList<Property>  cacheList  = new ArrayList ();

    private Property selectedProp;
    private String key;
    private String value;

    public void save() {
    	 Property p = new Property();
         p.setKey(key);
         p.setValue(value);
      
        
        cacheList.add(p);
        System.out.println("$$$$ "+cacheList);
       
        FacesContext context = FacesContext.getCurrentInstance();  
        
        context.addMessage(null, new FacesMessage("Successful added "+key + "=" + value));  
         key="";
        value="";
    }

    
    public List getCacheList() {
    	System.out.println(">>>>" +cacheList);
        return cacheList;
    }

   
    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
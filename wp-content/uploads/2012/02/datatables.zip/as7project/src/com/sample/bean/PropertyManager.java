package com.sample.bean;


import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

 
import com.sample.ejb.SingletonBean;
import com.sample.model.Property;

 

 

@ManagedBean(name="manager")
public class PropertyManager {
  
	@EJB
	SingletonBean ejb;
	
	ArrayList  cacheList;
	
	// Used for filtering data by filter.xhtml
	static List<SelectItem> valueList = new ArrayList<SelectItem>();
	
	 
	public List getValueList() {
		return valueList;
	}

	public void setValueList(List valueList) {
		this.valueList = valueList;
	}
	
	private String key;
	private String value;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public void save() {
		ejb.put(key, value);
		
		// Adding entry to the Filter Combo box
		valueList.add(new SelectItem(value));
		
		  
	}

	public void clear() {
		 
		cacheList.clear();
		 

	}
	public List getCacheList() {
		return ejb.getCache();
	}


}

package com.sample.bean;


import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.validation.constraints.Size;

import com.sample.ejb.SingletonBean;
import com.sample.model.Property;



@ManagedBean(name="manager")
public class PropertyManager {
  
	@EJB
	SingletonBean ejb;

	ArrayList  cacheList  = new ArrayList ();
	
	@Size(min=3, max=12,message="Key must be between 3 and 12 chars")
	private String key;
	private String value;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public void save() {
		ejb.put(key, value);
		key="";
		value="";
	}

	public void clear() {
		ejb.delete();

	}
	public List<Property> getCacheList() {
		return ejb.getCache();
	}
	public List autoComplete(String prefix) {
		List list = new ArrayList();
		for (Property element: getCacheList())
			list.add(element.getKey());
		return list;
	}

}

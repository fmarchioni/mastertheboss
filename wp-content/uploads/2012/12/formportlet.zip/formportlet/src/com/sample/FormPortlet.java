package com.sample;

import java.io.IOException;
import java.io.PrintWriter;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.RenderMode;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

public class FormPortlet extends GenericPortlet {

    @RenderMode(name = "view")
    public void display(RenderRequest request, RenderResponse response) throws PortletException, IOException {
    	   
    	  if (request.getParameter("result") != null) {
    		  getPortletContext().getRequestDispatcher("/output.jsp").include(request, response);
    	  }
    	  else {
    		  getPortletContext().getRequestDispatcher("/form.jsp").include(request, response);  
    	  }
    }

    @ProcessAction(name = "calculateAction")
    public void nameAction(ActionRequest request, ActionResponse response) throws PortletException {
        int number1=Integer.parseInt(request.getParameter("number1"));
        int number2=Integer.parseInt(request.getParameter("number2"));

    	response.setRenderParameter("result", String.valueOf(number1+number2));
    }
}
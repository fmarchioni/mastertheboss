<%@ taglib uri="http://java.sun.com/portlet_2_0" prefix="portlet" %>


<portlet:defineObjects/>


<div>
  <div class="portlet-section-header">Calculator Machine</div>
  <br/>
  <div class="portlet-section-body">Result: <%=renderRequest.getParameter("result") %></div>
  <br/>
  <a href="<portlet:renderURL portletMode='view' />">Reset</a>
  <br/>
</div>
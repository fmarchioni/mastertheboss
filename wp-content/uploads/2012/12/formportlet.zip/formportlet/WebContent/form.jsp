<%@ taglib uri="http://java.sun.com/portlet_2_0" prefix="portlet" %>


<portlet:defineObjects/>


<div>
  <div class="portlet-section-header">Calculator Machine</div>
  <br/>
  <div class="portlet-section-body">
    <form action='<portlet:actionURL name="calculateAction"/>' method="post">
      <span class="portlet-form-label">Enter two numbers</span>
      <input class="portlet-form-input-field" type="text" name="number1"/>
      <input class="portlet-form-input-field" type="text" name="number2"/>
        
      <input class="portlet-form-button" type="Submit" value="Calculate Sum"/>
    </form>
  </div>
  <br/>
</div>
